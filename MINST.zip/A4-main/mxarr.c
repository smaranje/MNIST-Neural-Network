#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <float.h>
#include <math.h>

#include "mxarr.h"

// Define the global variables
ERROR_CODES ERROR_CODE = ERR_NONE;
char ERROR_STRING[256] = "";

/*****************
Helper Functions
*****************/

Array *newmatrix(ELEMENT_TYPES type) {
    // Create a new array with 3x3 dimensions
    Array *matrix = newarray(3, type);

    // Check if the array creation was successful
    if (matrix == NULL) {
        return NULL;
    }

    // Update the dimension to 3x3
    matrix->dimno = 2; // Two-dimensional array
    matrix->dims[0] = 3;
    matrix->dims[1] = 3;

    return matrix;
}

/************************************
Part 1
Function 1 working
Function 2 working
Function 3 working
Function 4 working
Function 5 Not Working(ReadArray)
Function 6 Not Working(WriteArray)
)
*************************************/

void endswap(unsigned char bytes, void *input, void *output) {
    unsigned char *input_bytes = (unsigned char *)input;
    unsigned char *output_bytes = (unsigned char *)output;

    if (input_bytes == output_bytes) {
        // In-place reverse
        //int length = strlen((const char *)input_bytes);

        for (int i = 0; i < bytes / 2; i++) {
            unsigned char temp = input_bytes[i];
            input_bytes[i] = input_bytes[bytes - 1 - i];
            input_bytes[bytes - 1 - i] = temp;
        }
    } else {
        // Swap between input and output
        for (int i = 0; i < bytes; i++) {
            output_bytes[i] = input_bytes[bytes - 1 - i];
        }
    }
}

Array *newarray( uint32_t dim0, ELEMENT_TYPES type ){
  
  // Allocate memory for the Array structure
  Array *arr = (Array *)malloc(sizeof(Array));
    
    if (arr == NULL) {
        // Memory allocation for Array structure failed
        ERROR_CODE = ERR_MEMORY;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "newarray - malloc failed\n");
        printf("newarray - malloc failed\n");
        return NULL;
    }

    // Initialize Array structure fields
    arr->dimno = 1; // One-dimensional array
    arr->type = type;
    arr->dims[0] = dim0;
    arr->elno = dim0;
    
    // Calculate the size of the data array
    size_t data_size = dim0 * ELEMENT_SIZE(type);

    // Allocate memory for the data array
    arr->data = (unsigned char *)malloc(data_size);

    if (arr->data == NULL) {
        // Memory allocation for data array failed
        free(arr); // Free the previously allocated Array structure
        ERROR_CODE = ERR_MEMORY;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "newarray - malloc failed\n");
        return NULL;
    }

    return arr;

}

unsigned char inflatearray( Array *arr, uint32_t dim ){
    if (arr->dimno >= MAX_DIMS) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "inflate - dimensionality error\n");
        return 0;
    }

    // Calculate the new size for the last dimension
    uint32_t new_dim = arr->dims[arr->dimno - 1] / dim;

    if (arr->dims[arr->dimno - 1] % dim != 0) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "inflate - dimensionality error\n");
        return 0;
    }

    arr->dims[arr->dimno - 1] = dim;
    arr->dims[arr->dimno] = new_dim;
    arr->dimno++;

    return 1;
}



/* Function to reverse the inflate operation */
void flatten(Array *arr) {
    if (arr->dimno <= 1) {
        // Nothing to flatten if there's only one dimension
        return;
    }

    // Merge the last two dimensions
    uint32_t new_dim = arr->dims[arr->dimno - 2] * arr->dims[arr->dimno - 1];
    
    // Decrease the dimension count
    arr->dimno--;

    // Update the dimensions
    arr->dims[arr->dimno - 1] = new_dim;

    // Calculate the updated elno (number of elements)
    arr->elno = 1;
    for (unsigned char i = 0; i < arr->dimno; i++) {
        arr->elno *= arr->dims[i];
    }
}

Array *readarray(FILE *fp) {

    //fprintf(stderr,"start reading array");
    uint8_t magic[4];
    uint32_t dims[MAX_DIMS];
    Array *arr;

    // Read magic bytes
    if (fread(magic, sizeof(uint8_t), 4, fp) != 4) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "readarray - fread error\n");
        return NULL;
    }

    ELEMENT_TYPES type;
    unsigned char dimno;

    // Decode type and dimensionality from magic bytes
    if (magic[0] == 0 && magic[1] == 0) {
        type = (ELEMENT_TYPES)magic[2];
        dimno = magic[3];
    } else if (magic[2] == 0 && magic[3] == 0) {
        type = (ELEMENT_TYPES)magic[1];
        dimno = magic[0];
    } else {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "readarray - file format violation\n");
        return NULL;
    }

    if (dimno > MAX_DIMS) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "readarray – dimensionality error\n");
        return NULL;
    }

    unsigned int elno = 1;

    // Read dimension values
    for (unsigned char i = 0; i < dimno; i++) {
        if (fread(&dims[i], sizeof(uint32_t), 1, fp) != 1) {
            ERROR_CODE = ERR_VALUE;
            snprintf(ERROR_STRING, sizeof(ERROR_STRING), "readarray - fread error\n");
            return NULL;
        }

        if (magic[0] == 0 && magic[1] == 0) {
            //printf("Before: %d\n",dims[i]);
            endswap(sizeof(uint32_t), &dims[i], &dims[i]);
            //printf("After: %d\n",dims[i]);
        }

        elno *= dims[i];
    }
    //printf("Dim0 == %d\n",dims[0]);
    arr = newarray(elno, type);
    if (!arr) {
        return NULL;
    }

    arr->type = type;
   // arr->dimno = dimno;
    arr->elno = elno;


    // Use the inflatearray function to match dimensionality with `dims`
    for (unsigned char i = 0; i < dimno - 1; i++) {
        if (!inflatearray(arr, dims[i])) {
            // Handle error if inflation fails
            return NULL;
        }
    }

    if (fread(arr->data, ELEMENT_SIZE(type), elno, fp) != elno) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "readarray - fread error\n");
        // Optionally free allocated memory here
        return NULL;
    }

    // Handle endianness for the actual array data
    if (magic[0] == 0 && magic[1] == 0) {
        for (unsigned int i = 0; i < elno; i++) {
            unsigned char *element_ptr = arr->data + i * ELEMENT_SIZE(type);
            endswap(ELEMENT_SIZE(type), element_ptr, element_ptr);
        }
    }

    //printf("Dim0 == %d\n",arr->dims[0]);

    //fprintf(stderr,"returning array");
    return arr;
}

int writearray(FILE *fp, unsigned char bigendian, Array *arr) {
    // Write magic bytes based on endianness
    uint8_t magic[4];
    if (bigendian) {
        magic[0] = 0;
        magic[1] = 0;
        magic[2] = (uint8_t)arr->type;
        magic[3] = arr->dimno;
    } else {
        magic[0] = arr->dimno;
        magic[1] = (uint8_t)arr->type;
        magic[2] = 0;
        magic[3] = 0;
    }

    if (fwrite(magic, sizeof(uint8_t), 4, fp) != 4) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "writearray - write error\n");
        return 0;
    }

    // Write dimension values
    for (unsigned char i = 0; i < arr->dimno; i++) {
        uint32_t dim = arr->dims[i];
        if (bigendian) {
            endswap(sizeof(uint32_t), &dim, &dim);
        }
        if (fwrite(&dim, sizeof(uint32_t), 1, fp) != 1) {
            ERROR_CODE = ERR_VALUE;
            snprintf(ERROR_STRING, sizeof(ERROR_STRING), "writearray - write error\n");
            return 0;
        }
    }

    // Write data
    size_t elem_size = ELEMENT_SIZE(arr->type);
    if (bigendian && elem_size > 1) {
        unsigned char *temp_data = (unsigned char *)malloc(elem_size);
        if (!temp_data) {
            ERROR_CODE = ERR_MEMORY;
            snprintf(ERROR_STRING, sizeof(ERROR_STRING), "writearray - malloc failed\n");
            return 0;
        }
        for (unsigned int i = 0; i < arr->elno; i++) {
            endswap(elem_size, arr->data + i * elem_size, temp_data);
            if (fwrite(temp_data, elem_size, 1, fp) != 1) {
                free(temp_data);
                ERROR_CODE = ERR_VALUE;
                snprintf(ERROR_STRING, sizeof(ERROR_STRING), "writearray - write error\n");
                return 0;
            }
        }
        free(temp_data);
    } else {
        if (fwrite(arr->data, elem_size, arr->elno, fp) != (size_t)arr->elno) {
            ERROR_CODE = ERR_VALUE;
            snprintf(ERROR_STRING, sizeof(ERROR_STRING), "writearray - write error\n");
            return 0;
        }
    }

    return 1;
}




// Function to free the data and structure
void freearray(Array *arr) {
    free(arr->data);
    free(arr);
}

/***************************
Part 2
Function 7  Not Working(random03)
Function 8  Working
Function 9  Working
Function 10 Working(isMatrix)
Function 11 Not Working(isVector)
Function 12 Working(apply)
Function 13 Working(matrixgetdouble)
Function 14 Workiing(getUChar)
Function 15 Working(matrixgetcross)
Function 16 Working(mulop)
Function 17 Working(addop)
Function 18 Working(subop)
Function 19 Working (matrixmatrixop)
Function 20 Not Working(matrixvectorop)
Function 21 Working (scalarmatrixop)
Function 22 Working(matrixtranspose)
Function 23 Working(matrixsum)
Function 24 Working(matrixonehot)
Function 25 Working(matrixsumcols)





****************************/

void random03(double *x) {

    // Seed the random number generator (call this once in your program)
    static int seed_initialized = 0;
    if (!seed_initialized) {
        srand(time(NULL));
        seed_initialized = 1;
    }

    // Generate a random number between -0.3 and +0.3
    double random_value = ((double)rand() / RAND_MAX) * (POS - (NEG)) + (NEG);

    // Update the value at x with the random value
    *x = random_value;
}

void logistic(double *x) {
    // Calculate the logistic transformation
    double exp_value = exp(-(*x));
    *x = 1.0 / (1.0 + exp_value);
}

void square(double *x) {
    // Calculate the square of the value at x
    *x = (*x) * (*x);
}

unsigned char ismatrix( Array *arr ){

    // Check if the array is a matrix (2 dimensions and DOUBLE_TYPE)
    if (arr->dimno == 2 && arr->type == DOUBLE_TYPE) {
        return 1; // It's a matrix
    } else {
        return 0; // It's not a matrix
    }

}

unsigned char isvector(Array *arr) {

    if (ismatrix(arr) && (arr->dims[0] == 1)) {
        return 1; // It's a vector
    } else {
        return 0; // It's not a vector
    }
}




Array *apply(Array *arr, void (*fn)(double *)) {
    // Check if the array is NULL or the function pointer is NULL
    if (arr == NULL || fn == NULL) {
        return NULL;
    }

    for (unsigned int i = 0; i < arr->elno; i++) {
        double *element = (double *)(arr->data + i * ELEMENT_SIZE(arr->type));
        fn(element);
    }

    return arr;
}

Array *copy(Array *arr) {
    // Check if the array is NULL
    if (arr == NULL) {
        return NULL;
    }

    // Create a new Array structure
    Array *newArr = (Array *)malloc(sizeof(Array));
    if (newArr == NULL) {
        // Memory allocation failed
        ERROR_CODE = ERR_MEMORY;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "copy - malloc failed\n");
        return NULL;
    }

    // Copy metadata
    newArr->dimno = arr->dimno;
    newArr->type = arr->type;
    newArr->elno = arr->elno;

    // Allocate memory for data and copy data
    size_t dataSize = ELEMENT_SIZE(arr->type) * arr->elno;
    newArr->data = (unsigned char *)malloc(dataSize);
    if (newArr->data == NULL) {
        // Memory allocation failed
        ERROR_CODE = ERR_MEMORY;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "copy - malloc failed\n");
        free(newArr);
        return NULL;
    }

    // Copy the data
    memcpy(newArr->data, arr->data, dataSize);

    // Copy dimensions
    for (unsigned char i = 0; i < arr->dimno; i++) {
        newArr->dims[i] = arr->dims[i];
    }

    return newArr;
}

double *matrixgetdouble(Array *matrix, unsigned int i, unsigned int j) {
    // Check if the array is a matrix
    if (!ismatrix(matrix)) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "matrixgetdouble - not a matrix\n");
        printf("matrixgetdouble - not a matrix\n");
        return NULL;
    }

    // Calculate the address of the double element
    double *element = ((double*)matrix->data)+ (matrix->dims[1]*i) + j;

    return element;
}


unsigned char *getuchar(Array *arr, unsigned int i, unsigned int j) {
    // Check if the array is two-dimensional and contains unsigned integers
    if (arr->dimno != 2 || arr->type != UCHAR_TYPE) {
        ERROR_CODE = ERR_VALUE;
        snprintf(ERROR_STRING, sizeof(ERROR_STRING), "getuchar – invalid array\n");
        printf("Error!!!!\n");
        return NULL;
    }

    // Calculate the offset to the specified element
    size_t elementSize = ELEMENT_SIZE(arr->type);
    size_t rowSize = elementSize * arr->dims[1]; // Size of each row in bytes
    size_t offset = (i * rowSize) + (j * elementSize);

    // Return a pointer to the specified unsigned char element
    return (unsigned char *)(arr->data + offset);
}

Array *matrixcross(Array *multiplier, Array *multiplicand) {
    // Check if multiplier is a matrix
    if (!ismatrix(multiplier)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixcross - multiplier is not a matrix\n");
        printf("matrixcross - multiplier is not a matrix\n");
        return NULL;
    }

    // Check if multiplicand is a matrix
    if (!ismatrix(multiplicand)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixcross - multiplicand is not a matrix\n");
        printf("matrixcross - multiplicand is not a matrix\n");
        return NULL;
    }

    // Check if the number of columns in the multiplier matches the number of rows in the multiplicand
    if (multiplier->dims[1] != multiplicand->dims[0]) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixcross - bad dimensions\n");
        printf("matrixcross - bad dimensions\n");
        return NULL;
    }

    // Create a new matrix to store the result
    Array *result = newarray(multiplier->dims[0] * multiplicand->dims[1], DOUBLE_TYPE);
if (result == NULL) {
    // Handle memory allocation error
    return NULL;
}
inflatearray(result, multiplier->dims[0]);


    uint32_t i = 0;
    while (i < multiplier->dims[0]) {
        uint32_t j = 0;
        while (j < multiplicand->dims[1]) {
            double sum = 0.0;
            uint32_t k = 0;
            while (k < multiplier->dims[1]) {
                double *element1 = matrixgetdouble(multiplier, i, k);
                double *element2 = matrixgetdouble(multiplicand, k, j);

                sum += (*element1) * (*element2);
                k++;
            }
            // Set the result in the new array
            double *resultElement = matrixgetdouble(result, i, j);
            *resultElement = sum;
            j++;
        }
        i++;
    }

    return result;
}



double mulop(double x, double y) {
    // Multiply x and y and return the result
    return x * y;
}

double addop(double x, double y) {
    // Add x and y and return the result
    return x + y;
}

double subop(double x, double y) {
    // Subtract y from x and return the result
    return x - y;
}

Array *matrixmatrixop(Array *arr1, Array *arr2, double (*fn)(double, double)) {
    // Check if arr1 is a matrix
    if (!ismatrix(arr1)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixmatrixop - arr1 is not a matrix\n");
        return NULL;
    }

    // Check if arr2 is a matrix
    if (!ismatrix(arr2)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixmatrixop - arr2 is not a matrix\n");
        return NULL;
    }

    // Check if dimensions of arr1 and arr2 match
    if (arr1->dims[0] != arr2->dims[0] || arr1->dims[1] != arr2->dims[1]) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixmatrixop - bad dimensions\n");
        return NULL;
    }

    // Create a new array with dimensions matching arr1 and arr2
    Array *result = newarray(arr1->dims[0]*arr1->dims[1], DOUBLE_TYPE);
    inflatearray(result, arr1->dims[0]);

    // Perform element-wise operation on corresponding elements of arr1 and arr2
    for (uint32_t i = 0; i < arr1->dims[0]; i++) {
        for (uint32_t j = 0; j < arr1->dims[1]; j++) {
            double *element1 = matrixgetdouble(arr1, i, j);
            double *element2 = matrixgetdouble(arr2, i, j);
            double *resultElement = matrixgetdouble(result, i, j);
            *resultElement = fn(*element1, *element2);
        }
    }

    return result;

}

Array *matrixvectorop(Array *arr, Array *vec, double (*fn)(double, double)) {
    if (ismatrix(arr) == 0) {
        //SET_ERROR(ERR_VALUE, "matrixvectorop - arr is not a matrix");
        return NULL;
    }

    if (isvector(vec) == 0) {
        //SET_ERROR(ERR_VALUE, "matrixvectorop - vec is not a vector");
        return NULL;
    }

    if (arr->dims[1] != vec->dims[1]) {
        //SET_ERROR(ERR_VALUE, "matrixvectorop - bad dimensions");
        return NULL;
    }

    Array *result = newarray(arr->elno, DOUBLE_TYPE);
    inflatearray(result, arr->dims[0]);
    
    if (result == NULL) {
        return NULL;
    }
    for (int i = 0; i <arr->dims[0]; i++) {
        for(int j = 0; j<vec->dims[1]; j++){
            double *element1 = matrixgetdouble(arr,i,j);
            double *element2 = matrixgetdouble(vec,0,j);
            double *resultElement = matrixgetdouble(result,i,j);
            *resultElement = fn(*element1, *element2);
        }
    }
    return result;
}

Array *scalarmatrixop(double scalar, Array *arr, double (*fn)(double, double)) {
    // Check if arr is a matrix
    if (!ismatrix(arr)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "scalarmatrixop - arr is not a matrix\n");
        return NULL;
    }

    // Create a new matrix with dimensions matching arr
    Array *result = newarray(arr->dims[0]*arr->dims[1], DOUBLE_TYPE);
    inflatearray(result, arr->dims[0]); // 

    // Check if result creation was successful
    if (result == NULL) {
        return NULL;
    }

    for (uint32_t i = 0; i < arr->dims[0]; i++) {
        for (uint32_t j = 0; j < arr->dims[1]; j++) {
            double *element = matrixgetdouble(arr, i, j);
            double *resultElement = matrixgetdouble(result, i, j);
            *resultElement = fn(scalar, *element);
        }
    }

    return result;
}

Array *matrixtranspose(Array *original) {
    // Check if original is a matrix
    if (!ismatrix(original)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixtranspose - original is not a matrix\n");
        return NULL;
    }

    // Create a new array with a total number of elements equal to the product of the original matrix's dimensions
    Array *result = newarray(original->dims[0] * original->dims[1], DOUBLE_TYPE);
    if (result == NULL) {
        return NULL;
    }

    // Inflate the array to make it two-dimensional with dimensions inverted from the original
    if (!inflatearray(result, original->dims[1])) {
        free(result->data);
        free(result);
        return NULL;
    }

    // Transpose the elements from original to result
    for (uint32_t i = 0; i < original->dims[0]; i++) {
        for (uint32_t j = 0; j < original->dims[1]; j++) {
            double *element = matrixgetdouble(original, i, j);
            double *resultElement = matrixgetdouble(result, j, i); // Transpose i and j
            *resultElement = *element;
        }
    }

    return result;
}


double matrixsum(Array *arr) {
    // Check if arr is a matrix
    if (!ismatrix(arr)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixsum - arr is not a matrix\n");
        printf("matrixsum - arr is not a matrix\n");
        return 0.0;
    }

    double sum = 0.0;

    // Calculate the sum of all elements in arr
    for (uint32_t i = 0; i < arr->dims[0]; i++) {
        for (uint32_t j = 0; j < arr->dims[1]; j++) {
            double *element = matrixgetdouble(arr, i, j);
            sum += *element;
           // printf("i = %d, j = %d, sum = %f\n",i,j,sum);
        }
    }

    return sum;
}

Array *matrixonehot(Array *arr) {
    // Check if arr is a 1-dimensional UCHAR_TYPE array
    if ((arr->dimno == 1) && arr->type != UCHAR_TYPE) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixonehot - arr is not a 1-dimensional UCHAR_TYPE array\n");
        printf("matrixonehot - arr is not a 1-dimensional UCHAR_TYPE array\n");
        return NULL;
    }

    // Create a new array of DOUBLE_TYPE with dimensions matching the input array
    Array *result = newarray(arr->elno * 10, DOUBLE_TYPE);
    inflatearray(result,arr->dims[0]);

    //printf("Dimentions 1: %d\n", result->dims[1]);

    // Check if result creation was successful
    if (result == NULL) {
        printf("result is NULL\n");
        return NULL;
    }

    for (unsigned int i = 0; i < result->elno; i++) {
        double *element = (double *)(result->data + i * ELEMENT_SIZE(arr->type));
        *element = 0.0;
    }

    // Set the one-hot values
    for (unsigned int i = 0; i < result->dims[0]; i++) {
        // Get the value from the input array
        unsigned char *value = (unsigned char *)(arr->data + i * ELEMENT_SIZE(UCHAR_TYPE));
        
        double *target = matrixgetdouble(result,i,*value);

        *target = 1.0;

    }


    return result;
}


Array *matrixsumcols(Array *arr) {
    // Check if arr is a matrix
    if (!ismatrix(arr)) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixsumcols - arr is not a matrix\n");
        return NULL;
    }

    // Create a new array with the same number of elements as the number of columns in arr
    Array *result = newarray(arr->dims[1], DOUBLE_TYPE);
    if (result == NULL) {
        return NULL;
    }

    // Inflate the array to make it two-dimensional with one row
    if (!inflatearray(result, 1)) {
        free(result->data);
        free(result);
        return NULL;
    }

    for (uint32_t j = 0; j < arr->dims[1]; j++) {
        double sum = 0.0;
        for (uint32_t i = 0; i < arr->dims[0]; i++) {
            double *element = matrixgetdouble(arr, i, j);
            sum += *element;
        }
        double *resultElement = matrixgetdouble(result, 0, j);
        *resultElement = sum;
    }

    return result;
}


Array *arrgetmatrix(Array *arr, unsigned int i) {

    // Check if arr is NULL
    if (!arr) {
        //printf("Debug: arrgetmatrix - input array is NULL\n");
        return NULL;
    }

    if (arr->dimno != 3) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "arrgetmatrix - not a 3-dimensional array\n");
        //printf("Debug: arrgetmatrix - not a 3-dimensional array\n");
        return NULL;
    }

    // Determine the dimensions of the new 2D array
    uint32_t numRows = arr->dims[1]; // Number of rows
    uint32_t numCols = arr->dims[2]; // Number of columns
    //printf("Debug: numRows = %u, numCols = %u\n", numRows, numCols);

    // Create a new 2D array with the same data type as the input array
    Array *result = newarray(numRows * numCols, arr->type);
    if (!result) {
        //printf("Debug: arrgetmatrix - Failed to create new array\n");
        return NULL;
    }
    
    inflatearray(result, numRows);
    if (result->dimno != 2 || result->dims[0] != numRows || result->dims[1] != numCols) {
        //printf("Debug: arrgetmatrix - Failed to inflate new array to 2D\n");
        return NULL;
    }

    // Copy values from the 3D input array to the new 2D array for the specified index i
    for (uint32_t j = 0; j < numRows; j++) {
        for (uint32_t k = 0; k < numCols; k++) {
            // Calculate the index in the 3D input array based on i, j, and k
            uint32_t index3D = i * (numRows * numCols) + j * numCols + k ;

            // Calculate the index in the 2D result array based on j and k
            uint32_t index2D = j * numCols + k;

            // Convert the value from UCHAR_TYPE to DOUBLE_TYPE and set it in the new 2D array
            ((unsigned char*)result->data)[index2D] = ((unsigned char*)arr->data)[index3D];

            //printf("Resultgetmatrix: %d, %d, %d\n",i,j, ((unsigned char*)result->data)[index2D]);
        }
    }
    //printf("Debug: arrgetmatrix - Successfully created 2D matrix\n");
    return result;
}

/***********************
    ASSIGNMENT 4 
************************/

Array *matrixtodouble(Array *arr) {
    fprintf(stderr, "Initializing matrixtodouble function\n");

    // Check if the input array is valid
    if (arr->dimno != 2 || arr->type != UCHAR_TYPE) {
        strcpy(ERROR_STRING, "Dimensionality error - not a 2D array of UCHAR_TYPE\n");
        printf("%s\n", ERROR_STRING);
        return NULL;
    }

    Array *toArray = newarray(arr->elno, DOUBLE_TYPE);

    if (toArray == NULL) {
        return NULL;
    }

    fprintf(stderr, "Starting conversion\n");

    for (unsigned int i = 0; i < arr->dimno - 1; i++) {
        inflatearray(toArray, arr->dims[i]);
    }

    fprintf(stderr, "Converting elements\n");

    for (unsigned int i = 0; i < arr->dims[0]; i++) {
        for (unsigned int j = 0; j < arr->dims[1]; j++) {
            fprintf(stderr, "i, j = %d, %d\n", i, j);
            unsigned char *tempUchar = getuchar(arr, i, j);

            if (tempUchar == NULL) {
                return NULL;
            }

            double *tempDchar = matrixgetdouble(toArray, i, j);

            if (tempDchar == NULL) {
                return NULL;
            }

            *tempDchar = (double)(*tempUchar);
        }
    }

    fprintf(stderr, "Conversion complete\n");
    return toArray;
}


Array *matrixonecold(Array *arr) {
    // Check if arr is a 2-dimensional DOUBLE_TYPE array
    if (arr->dimno != 2 || arr->type != DOUBLE_TYPE) {
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "matrixonecold - arr is not a 2-dimensional DOUBLE_TYPE array\n");
        printf("matrixonecold - arr is not a 2-dimensional DOUBLE_TYPE array\n");
        return NULL;
    }

    // Create a new 1-dimensional UCHAR_TYPE array
    Array *result = newarray(arr->dims[0], UCHAR_TYPE);

    // Check if result creation was successful
    if (result == NULL) {
        printf("result is NULL\n");
        return NULL;
    }

    for (unsigned int i = 0; i < result->dims[0]; i++) {
        double max_value = -DBL_MAX;
        unsigned char max_index = 0;

        for (unsigned int j = 0; j < arr->dims[1]; j++) {
            double *element = (double *)(arr->data + (i * arr->dims[1] + j) * ELEMENT_SIZE(DOUBLE_TYPE));

            if (*element > max_value) {
                max_value = *element;
                max_index = (unsigned char)j;
            }
        }

        unsigned char *target = (unsigned char *)(result->data + i * ELEMENT_SIZE(UCHAR_TYPE));
        *target = max_index;
    }

    return result;
}


Array *matrixconfusion(Array *val, Array *tar) {

    printf("Entering matrixconfusion function.\n");
    // Confirm that val and tar are both 1-dimensional arrays of the same size and of type UCHAR_TYPE
    if (!val || !tar) {
        printf("One of the input arrays is NULL.\n");
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "Invalid input. One of the arrays is NULL.");
        return NULL;
    }

    // Confirm that val and tar are both 1-dimensional arrays...
    if (val->dimno != 1 || tar->dimno != 1 || val->dims[0] != tar->dims[0] || val->type != UCHAR_TYPE || tar->type != UCHAR_TYPE) {
        printf("Input array validation failed.\n");
        ERROR_CODE = ERR_VALUE;
        strcpy(ERROR_STRING, "Invalid input arrays. They must be 1-dimensional, of the same size, and of type UCHAR_TYPE.");
        return NULL;
    }

    printf("Input arrays validated successfully.\n");
    // Create a new 10x10 2-dimensional array of type DOUBLE_TYPE
    Array *outputArray = newarray(100, DOUBLE_TYPE);

    if (!outputArray) {
        printf("Failed to create output array.\n");
        ERROR_CODE = ERR_MEMORY;
        strcpy(ERROR_STRING, "Memory allocation failed for output array.");
        return NULL;
    }

    // Inflate the array to 2 dimensions, each of size 10
    if (!inflatearray(outputArray, 10)) {
        printf("Failed to inflate output array to 2 dimensions.\n");
        ERROR_CODE = ERR_MEMORY;
        strcpy(ERROR_STRING, "Failed to inflate output array.");
        freearray(outputArray);
        return NULL;
    }

    printf("Output array created and inflated successfully.\n");

    // Initialize the output array with zeros
    double *outputData = (double *)outputArray->data;
    for (int i = 0; i < 100; i++) {
        outputData[i] = 0.0;
    }

    printf("Output array initialized with zeros.\n");

    // [Element processing code remains the same]

    return outputArray;
}
