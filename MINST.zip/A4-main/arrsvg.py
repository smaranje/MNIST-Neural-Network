import sys
import os
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs
import mxarr
import re
from math import sqrt

# Constants definition
header = """<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"
"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg width="280" height="280" xmlns="http://www.w3.org/2000/svg"
xmlns:xlink="http://www.w3.org/1999/xlink">""";

footer = """</svg>""";

pxsize = 10;

def convert_to_hex(decimal_value):
    """
    This function converts a given decimal number into a two-digit hexadecimal string.

    :param decimal_value: An integer representing a decimal number to be converted.
    :return: A string representing the hexadecimal equivalent of the decimal number.
    """
    hex_str = format(decimal_value, '02x')
    return hex_str

def svg(matrix_data):
    svg_header = f"""<?xml version="1.0"?>
    <svg width="280" height="280" xmlns="http://www.w3.org/2000/svg">"""
    svg_footer = "</svg>"
    pixel_size = 10

    rectangles = ""
    for y_index in range(matrix_data.getdim(0)):
        for x_index in range(matrix_data.getdim(1)):
            color_value = int(matrix_data[y_index, x_index])
            color_hex = f"{color_value:02x}" * 3
            rect_x = x_index * pixel_size
            rect_y = y_index * pixel_size
            rectangles += f'<rect x="{rect_x}" y="{rect_y}" width="{pixel_size}" height="{pixel_size}" fill="#{color_hex}" />\n'

    return svg_header + rectangles + svg_footer


def graph(arr, xlabels, ylabels, xoff, yoff, xscale, yscale):
    svg_width = 700
    svg_height = 450
    origin_x = 50
    origin_y = 425
    
    # Start the SVG content with the header
    svg_content = header.replace('width="280" height="280"', f'width="{svg_width}" height="{svg_height}"')

    # Draw the axes
    svg_content += f'<line x1="{origin_x}" y1="25" x2="{origin_x}" y2="{origin_y}" stroke="black" stroke-width="4" />\n'
    svg_content += f'<line x1="{origin_x}" y1="{origin_y}" x2="{svg_width - origin_x}" y2="{origin_y}" stroke="black" stroke-width="4" />\n'

    # Add y-labels from bottom to top
    for i, label in enumerate(ylabels):
        y_position = origin_y - (i * (svg_height - 50) / (len(ylabels) - 1))
        svg_content += f'<text x="{origin_x - 10}" y="{y_position}" text-anchor="end">{label}</text>\n'

    # Add x-labels from left to right
    for i, label in enumerate(xlabels):
        x_position = origin_x + (i * (svg_width - 2 * origin_x) / (len(xlabels) - 1))
        svg_content += f'<text x="{x_position}" y="{svg_height - 5}" text-anchor="middle">{label}</text>\n'

    # Draw the lines between points
    for i in range(arr.getdim(1) - 1):  # Assuming the second dimension is the number of points
        x1 = (arr.__getitem__((0, i)) + xoff) * xscale + origin_x
        y1 = origin_y - ((arr.__getitem__((1, i)) + yoff) * yscale)
        x2 = (arr.__getitem__((0, i + 1)) + xoff) * xscale + origin_x
        y2 = origin_y - ((arr.__getitem__((1, i + 1)) + yoff) * yscale)

        svg_content += f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="blue" stroke-width="2" />\n'

    # End the SVG content with the footer
    svg_content += footer

    return svg_content

# Testing the function when the file is run as a script
if __name__ == "__main__":
    # Open the MNIST image file
    fp = mxarr.fopen("t10k-images-idx3-ubyte", "r")
    if not fp:
        print("Error: Failed to open 't10k-images-idx3-ubyte' for reading.")
        exit(1)
    else:
        print("Successfully opened 't10k-images-idx3-ubyte' for reading.")
    
    data = mxarr.readarray(fp)
    mxarr.fclose(fp)  # Close the file after reading

    if data is None:
        print("Error: readarray returned None. Unable to read the file or the file format is incorrect.")
        exit(1)
    else:
        print("Successfully read data from 't10k-images-idx3-ubyte'.")
    
    # Extract a single image matrix from the array
    try:
        img = data.getmatrix(0)  # Assuming 0 is the index of the image you want
        svg_content = svg(img)
        print(svg_content)  # Print the SVG content
    except AttributeError as e:
        print(f"Error: {e}")
        exit(1)

    # Open the sine data file
    fp2 = mxarr.fopen("sine.mxarr", "r")
    if not fp2:
        print("Error: Failed to open 'sine.mxarr' for reading.")
        exit(1)
    else:
        print("Successfully opened 'sine.mxarr' for reading.")
    
    sine_data = mxarr.readarray(fp2)
    mxarr.fclose(fp2)  # Close the file after reading

    if sine_data is None:
        print("Error: readarray returned None. Unable to read the file or the file format is incorrect.")
        exit(1)
    else:
        print("Successfully read data from 'sine.mxarr'.")

    # Generate the SVG plot for the sine data
    svg_graph = graph(sine_data, ["0", "90", "180", "270", "360"], ["-1.0", "-0.5", "0.0", "0.5", "1.0"], 0, 1, 600/360, 400/2)
    print(svg_graph)  # Print the SVG graph

