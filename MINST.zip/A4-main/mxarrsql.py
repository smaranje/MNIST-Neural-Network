import os
import sqlite3
import mxarr

class Database:
    def __init__(self, reset=False):
        # Check if reset is True and delete the database file if it exists
        if reset and os.path.exists("mxarr.db"):
            os.remove("mxarr.db")

        # Create or open the SQLite database
        self.connection = sqlite3.connect("mxarr.db")
        
        # Turn off journaling to avoid NFS file locking issues
        self.connection.execute('pragma journal_mode=OFF')

        self.cursor = self.connection.cursor()

    def create_tables(self):
        try:
            #print("Creating tables...")
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS Arrays (
                NAME VARCHAR(64) PRIMARY KEY NOT NULL,
                DIMNO INTEGER NOT NULL,
                DATATYPE INTEGER NOT NULL,
                DIMS0 INTEGER NOT NULL,
                DIMS1 INTEGER NOT NULL,
                ELNO INTEGER NOT NULL
            )
            ''')
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS DoubleData (
                ARRAYNAME VARCHAR(64),
                I INTEGER,
                J INTEGER,
                VALUE FLOAT,
                PRIMARY KEY (I, J, ARRAYNAME),
                FOREIGN KEY (ARRAYNAME) REFERENCES Arrays(NAME)
            )
            ''')
            self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS IntegerData (
                ARRAYNAME VARCHAR(64),
                I INTEGER,
                J INTEGER,
                VALUE INTEGER,
                PRIMARY KEY (I, J, ARRAYNAME),
                FOREIGN KEY (ARRAYNAME) REFERENCES Arrays(NAME)
            )
            ''')
            self.connection.commit()  # Commit the changes to the database
            #print("Tables created successfully.")
        except sqlite3.Error as e:
            print(e)

    def __setitem__(self, table, values):
        try:
            # Create the table if it doesn't exist
            #self.cursor.execute(f"CREATE TABLE IF NOT EXISTS {table} ({', '.join(table.columns)});")

            # Insert the values from the tuple into the table
            placeholders = ", ".join(["?" for _ in values])
            self.cursor.execute(f"INSERT INTO {table} VALUES ({placeholders});", values)
            self.connection.commit()
        except sqlite3.Error as e:
            print(f"SQLite error: {e}")

    def store_arr(self, arrname, arr):
        #print(f"Storing array '{arrname}'...")

        if arr.dimno != 2:
            raise ValueError("arr must be two-dimensional")
        #else:
           # print(f"Array '{arrname}' is two-dimensional.")

        if arr.type == mxarr.UCHAR_TYPE:
            datatype = mxarr.UCHAR_TYPE
        elif arr.type == mxarr.DOUBLE_TYPE:
            datatype = mxarr.DOUBLE_TYPE
        else:
            raise ValueError("Unsupported data type")

        dimno = arr.dimno
        dims0 = arr.getdim(0)
        dims1 = arr.getdim(1)
        elno = arr.elno

        #print(f"Array '{arrname}' attributes: DataType={datatype}, Dimensions=({dims0}, {dims1}), Number of Elements={elno}.")

        self.cursor.execute("INSERT INTO Arrays (NAME, DIMNO, DATATYPE, DIMS0, DIMS1, ELNO) VALUES (?, ?, ?, ?, ?, ?);",
                            (arrname, dimno, datatype, dims0, dims1, elno))
        #print(f"Inserted attributes for '{arrname}' into Arrays table.")

        table_name = "IntegerData" if datatype == mxarr.UCHAR_TYPE else "DoubleData"
        #print(f"Data for '{arrname}' will be stored in '{table_name}' table.")

        data_list = []

        for i in range(dims0):
            for j in range(dims1):
                value = float(arr[i, j]) if datatype == mxarr.DOUBLE_TYPE else int(arr[i, j])
                #print(f"Preparing to insert value {value} for [{i}, {j}] into '{table_name}'.")
                data_list.append((arrname, i, j, value))

        self.cursor.executemany(f"INSERT INTO {table_name} (ARRAYNAME, I, J, VALUE) VALUES (?, ?, ?, ?);", data_list)
        self.connection.commit()
        #print(f"Data for '{arrname}' inserted into {table_name} table and committed to the database.")


    def retrieve_arr(self, arrname):
        #print(f"Initiating retrieval of array '{arrname}' from the database...")
        try:
            # Execute SQL command to retrieve array metadata
            self.cursor.execute("SELECT DATATYPE, DIMNO, DIMS0, DIMS1 FROM Arrays WHERE NAME=?", (arrname,))
            row = self.cursor.fetchone()
            if row is None:
                raise ValueError(f"Array with name '{arrname}' not found in the database.")
            datatype, dimno, dims0, dims1 = row
            #print(f"Metadata for array '{arrname}' retrieved: DataType={datatype}, Dimensions=({dims0}, {dims1}).")

            # Confirm that the datatype is one that we can handle
            if datatype not in [mxarr.UCHAR_TYPE, mxarr.DOUBLE_TYPE]:
                raise ValueError(f"Unsupported data type: {datatype}")
            #print(f"Data type {datatype} is supported.")

            # Prepare to create a one-dimensional mxarr.Array object based on the retrieved metadata
            #print(f"Creating a one-dimensional mxarr.Array object for array '{arrname}'.")
            retrieved_array = mxarr.Array(dims0 * dims1, datatype)
            #print(f"One-dimensional mxarr.Array object created with length {dims0 * dims1}.")

            # Now we need to "inflate" this one-dimensional array to two dimensions if necessary
            if dimno == 2:
                #print(f"Inflating array to two dimensions ({dims0}, {dims1}).")
                retrieved_array.inflate(dims1)
            
            #print("Type: ", retrieved_array.type)
            # Determine the table name to retrieve the data from
            table_name = "IntegerData" if datatype == mxarr.UCHAR_TYPE else "DoubleData"
            # print(f"Data will be retrieved from '{table_name}' table.")

            # Execute SQL command to retrieve array data
            # print(f"Retrieving data for array '{arrname}' from the table '{table_name}'.")
            self.cursor.execute(f"SELECT I, J, VALUE FROM {table_name} WHERE ARRAYNAME=?", (arrname,))

            # Process each row of data returned by the database
            for row in self.cursor.fetchall():
                i, j, value = row
                #print(retrieved_array.dimno)
                #print(retrieved_array.type)
                #print(f"Retrieved value {value} for array '{arrname}' at position [{i}, {j}].")
                retrieved_array[i, j] = value  # Convert value to the correct type and assign to the array

            #print(f"Array '{arrname}' has been fully retrieved and reconstructed.")
            return retrieved_array

        except sqlite3.Error as e:
            print(f"SQLite error occurred: {e}")
        except ValueError as e:
            print(f"Value error: {e}")

    def clear_tables(self):
        try:
            self.cursor.execute("DELETE FROM Arrays;")
            self.cursor.execute("DELETE FROM DoubleData;")
            self.cursor.execute("DELETE FROM IntegerData;")
            self.connection.commit()
            print("All tables cleared successfully.")
        except sqlite3.Error as e:
            print(f"SQLite error occurred while clearing tables: {e}")

    def listarr(self):
        try:
            self.cursor.execute("SELECT NAME FROM Arrays;")
            names = [row[0] for row in self.cursor.fetchall()]  # Extracting the first element of each tuple
            return names
        except sqlite3.Error as e:
            print(f"SQLite error occurred while listing array names: {e}")
            return []
        
    def close(self):
        """Closes the database connection."""
        self.connection.close()    


