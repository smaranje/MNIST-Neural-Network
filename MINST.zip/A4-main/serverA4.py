import sys
import cgi
import os
import re
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import mxarr
import json
import mxarrsql
import arrsvg
import subprocess
from arrsvg import svg
from arrsvg import graph

# Directory where your .l2 files and SVG graphs are stored
L2_FILES_DIRECTORY = "/home/undergrad/1/smaranje/Desktop/CIS_2750/l2_files"
SVG_DIRECTORY = "/home/undergrad/1/smaranje/Desktop/CIS_2750/SVG"

publicFiles = ["/index.html", "/main.js", "/train_network.html", "/line_graph.html",
               "/evaluation_view.html", "/", "/main.css", "/progress_view.html"]

# Function to log debug messages
def log_debug(message):
    print(f"DEBUG: {message}", file=sys.stderr)

def generate_array_list_html(self, array_names):
    html_content = '<form id="deleteForm">'
    for array_name in array_names:
        html_content += f'<input type="checkbox" name="arrays" value="{array_name}"> {array_name}<br>'
    html_content += '<input type="submit" value="Delete Selected Arrays">'
    html_content += '</form>'
    return html_content


class MyRequestHandler(BaseHTTPRequestHandler):

    def send_html_response(self, html_content):
        """Utility function to send HTML response."""
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(html_content.encode('utf-8'))

    def do_GET(self):
        try:
            log_debug(f"Received GET request for: {self.path}")

            if self.path == "/":
                self.path = "/index.html"

            elif self.path in publicFiles:
                pathString = self.path.split(".")
                fileType = "text/" + pathString[1]

                self.send_response(200)
                self.send_header("Content-type", fileType)  # sending header

                # reading in file HTML
                fp = open(self.path[1:])
                webPage = fp.read()

                fp.close()

                self.send_header("Content-length", len(webPage))
                self.end_headers()

                self.wfile.write(bytes(webPage, "utf-8"))

            elif self.path == "/arrays":
            # Endpoint to serve the array data in JSON format
                db = mxarrsql.Database()
                try:
                    array_names = db.listarr()
                    db.close()  # Always close the database connection
                    self.send_response(200)
                    self.send_header("Content-type", "application/json")
                    self.end_headers()
                    self.wfile.write(json.dumps(array_names).encode('utf-8'))
                except Exception as e:
                    log_debug(f"Error retrieving arrays: {e}")
                    self.send_error(500, "Internal Server Error")


            elif self.path == "/progress_view.html":
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()

                # Read and serve the progress_view.html file
                with open("progress_view.html", "rb") as file:
                    self.wfile.write(file.read())

            elif self.path == "/get_l2_files":
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()

                # Retrieve the list of .l2 files from the L2_FILES_DIRECTORY
                l2_files = [{"name": f, "lastModified": os.path.getmtime(os.path.join(L2_FILES_DIRECTORY, f))} for f in os.listdir(L2_FILES_DIRECTORY) if f.endswith('.l2')]
                log_debug(f"L2 files to send: {json.dumps(l2_files)}")

                # Send the JSON response
                self.wfile.write(json.dumps(l2_files).encode('utf-8'))

            elif self.path.startswith("/get-svg-graph"):
                # Parse query parameters
                query_components = parse_qs(urlparse(self.path).query)
                selected_l2_file = query_components.get("file", [None])[0]
                log_debug(f"Requested SVG for L2 file: {selected_l2_file}")

                if selected_l2_file:
                    # Construct the full path to the corresponding SVG graph file
                    svg_file = os.path.join(SVG_DIRECTORY, selected_l2_file.replace(".l2", ".svg"))
                    log_debug(f"Looking for SVG file at: {svg_file}")
                    
                    # Check if the SVG graph file exists
                    if os.path.exists(svg_file):
                        log_debug(f"SVG file found: {svg_file}")
                        # Read the SVG graph file and send it as the response
                        with open(svg_file, "rb") as f:
                            self.send_response(200)
                            self.send_header("Content-type", "image/svg+xml")
                            self.end_headers()
                            self.wfile.write(f.read())
                    else:
                        log_debug(f"SVG file not found at: {svg_file}")
                        self.send_error(404, "SVG graph not found")
                else:
                    log_debug("No 'file' query parameter provided for SVG request.")
                    self.send_error(400, "Bad Request: Missing 'file' query parameter")

        except Exception as e:
            log_debug(f"Exception in GET request handling: {str(e)}")
            self.send_error_message(str(e))

    def send_error_message(self, message):
        self.send_response(500)
        self.send_header("Content-type", "text/plain")
        self.end_headers()
        self.wfile.write(message.encode('utf-8'))

    def do_POST(self):
        try:
            log_debug(f"Received POST request for: {self.path}")

            if self.path == "/create-tables":
                # Handle the request to create database tables

                # Create an instance of the Database class
                db = mxarrsql.Database();
                db.create_tables()
                db.close()

                # Respond with a success message
                self.send_response(200)
                self.send_header("Content-type", "application/json")
                self.end_headers()
                response_data = {"message": "Database tables created successfully"}
                self.wfile.write(json.dumps(response_data).encode('utf-8'))

            elif self.path == "/launchNN":
                content_length = int(self.headers['Content-Length'])
                post_data = self.rfile.read(content_length)
                data = json.loads(post_data.decode('utf-8'))

                name = data.get("name")
                start = data.get("start")
                end = data.get("end")

                if name and start and end:
                    log_debug(f"Launching NN.py with parameters: Name - {name}, Start - {start}, End - {end}")
                    # Use subprocess.Popen to safely execute the command
                    command = ["python3", "NN.py", name, str(start), str(end)]
                    subprocess.Popen(command)
                    
                    self.send_response(200)
                    self.send_header("Content-type", "application/json")
                    self.end_headers()
                    response_data = {"message": "NN.py has been started as a background process"}
                    self.wfile.write(json.dumps(response_data).encode('utf-8'))
                else:
                    self.send_error(400, "Bad Request: Missing parameters")

        except Exception as e:
            log_debug(f"Exception in POST request handling: {str(e)}")
            self.send_error_message(str(e))

if __name__ == "__main__":
    if len(sys.argv) < 2:
        log_debug("Usage: server.py [PORT]")
        sys.exit(1)

    port = int(sys.argv[1])
    log_debug(f"Starting server on port {port}")
    server = HTTPServer(('localhost', port), MyRequestHandler)
    server.serve_forever()
